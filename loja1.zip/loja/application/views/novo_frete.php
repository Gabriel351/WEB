<div id="homebody">
    <div class="row-fluid" >
        <?php
            echo form_open(base_url('administracao/incluir_frete')) . "<br>" . "<br>" .
            form_label("Peso mínimo:") .
            form_input(array('name'=>'peso_de', 'step'=>'any', 'type'=>'number')) . "<br>" . "<br>" .
            form_label("Peso máximo:") .
            form_input(array('name'=>'peso_ate', 'step'=>'any', 'type'=>'number')) . "<br>" . "<br>" .
            form_label("Preço:") .
            form_input(array('name'=>'preco', 'step'=>'any', 'type'=>'number')) . "<br>" . "<br>" .
            form_label("Adicional Kg:") .
            form_input(array('name'=>'kg_adicional', 'step'=>'any', 'type'=>'number')) . "<br>" . "<br>" .
            form_label("UF:") .
            form_input(array('name'=>'uf')) . "<br>" . "<br>" .
            form_submit("btnEdit", "Incluir novo frete") . "<br>" . "<br>" .
            form_close();
        ?>
    </div>
