<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3>Frete</h3>
    </div>

    <?php
        if($operacao == 1) {
            echo "<script type='text/javascript'>" .
            "alert('Operação realizada com sucesso!'); " .
            "</script>";
        }
        if($operacao == 2) {
            echo "<script type='text/javascript'>" .
            "alert('A operação falhou!'); " .
            "</script>";
        }
    ?>
    <div class="container">
        <table class="table table-bordered table-striped" id="tabela">
            <tr>
                <th >Peso mínimo</th>
                <th>Peso máximo</th>
                <th >Preço</th>
                <th>Adicional Kg</th>
                <th>UF</th>
                <th id='oper3'>Operações</th>
            </tr>
            <?php
                foreach ($frete as $f) {
                    echo "<tr>" .
                        "<td>" . $f->peso_de . "</td>" .
                        "<td>" . $f->peso_ate . "</td>" .
                        "<td>" . $f->preco . "</td>" .
                        "<td>" . $f->adicional_kg . "</td>" .
                        "<td>" . $f->uf . "</td>" .

                        "<td>" . anchor(base_url("administracao/frete_edit_view/". $f->id),
                        "Editar",array("class"=>"btn btn-warning","id"=>"botao")) .
                        anchor(base_url("administracao/excluir_frete/" . $f->id),"Excluir",array("class"=>"btn btn-danger","id"=>"botao2")); "</td>" .
                    "</tr>";
                }
            ?>
        </table>
        <?php
            echo anchor(base_url("administracao/frete_view"),"Novo Item",array("class"=>"btn btn-primary","id"=>"botao1"));
        ?>
    </div>

</div>
