<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3>Seja Bem-Vindo à área administrativa.</h3>
        <p>Aqui você poderá Incluir, Alterar ou Excluir registros nas tabelas de categorias, produtos ou frete.</p>
    </div>
        <div class="row-fluid">
        <?php
            echo "<div class='span4 caixacategoria'>" .
             anchor(base_url("administracao/categorias"),"Cadastro de categorias",array("class"=>"btn btn-medium btn-primary")) .
             "</div>" .
             "<div class='span4 caixacategoria'>" .
             anchor(base_url("administracao/produtos/" . 0),"Cadastro de produtos",array("class"=>"btn btn-medium btn-primary")) .
             "</div>" .
             "<div class='span4 caixacategoria'>" .
             anchor(base_url("administracao/frete/" . 0),"Tabela de fretes",array("class"=>"btn btn-medium btn-primary")) .
             "</div>";
        ?>
        </div>
</div>
