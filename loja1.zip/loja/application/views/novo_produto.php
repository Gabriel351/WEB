<div id="homebody">
    <div class="row-fluid" >
        <?php
            echo form_open(base_url('administracao/salvar_produto')) . "<br>" . "<br>" .
            form_label("Código") .
            form_input(array('name'=>'codigo')) . "<br>" . "<br>" .
            form_label("Título") .
            form_input(array('name'=>'titulo')) . "<br>" . "<br>" .
            form_label("Descrição") . "<br>" .
            form_textarea(array('name'=>'descricao')) . "<br>" . "<br>" .
            form_label("Categoria") . "<br>";
            foreach($categorias as $c) {
                echo form_checkbox("categorias[]", $c->id, false) . " " .
                form_label( $c->titulo) . "<br>";
            }
            echo "<br>" . form_label("Preço") .
            form_input(array('name'=>'preco', 'type'=>'number', 'step'=>'any')) . "<br>" . "<br>" .
            form_label("Largura da caixa em mm") .
            form_input(array('name'=>'largura', 'type'=>'number')) . "<br>" . "<br>" .
            form_label("Altura da caixa em mm") .
            form_input(array('name'=>'altura', 'type'=>'number')) . "<br>" . "<br>" .
            form_label("Comprimento da caixa em mm") .
            form_input(array('name'=>'comprimento', 'type'=>'number')) . "<br>" . "<br>" .
            form_label("Peso da caixa em gramas") .
            form_input(array('name'=>'peso', 'type'=>'number')) . "<br>" . "<br>" .
            form_submit("btnEdit", "Incluir Novo Produto") . "<br>" . "<br>" .
            form_close();
        ?>
    </div>
</div>
