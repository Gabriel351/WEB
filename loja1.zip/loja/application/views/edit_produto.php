<div id="homebody">
    <div class="row-fluid" >
        <?php
            echo form_open(base_url('administracao/update_produto')) . "<br>" . "<br>" .
            form_label("Código") .
            form_input(array('name'=>'codigo', 'value'=>$produto[0]->codigo)) . "<br>" . "<br>" .
            form_label("Título") .
            form_input(array('name'=>'titulo', 'value'=>$produto[0]->titulo)) . "<br>" . "<br>" .
            form_label("Descrição") . "<br>" .
            form_textarea(array('name'=>'descricao', 'value'=>$produto[0]->descricao)) . "<br>" . "<br>" .
            form_label("Categoria") . "<br>";

            //foreach, foreach, foreach...
            //categorias preenchidas
            foreach($categorias1 as $c) {
                foreach ($categorias2 as $c1) {
                    if ($c->id == $c1->categoria) {
                        echo form_checkbox("categorias[]", $c->id, true) . " " .
                        form_label($c->titulo) . "<br>";
                        break;
                    }
                }
            }

            //categorias não preenchidas
            foreach($categorias1 as $c) {
                $aux = true;
                foreach ($categorias2 as $c1) {
                    if ($c->id == $c1->categoria) {
                        $aux = false;
                        break;
                    }
                }
                if ($aux) {
                    echo form_checkbox("categorias[]", $c->id, false) . " " .
                    form_label($c->titulo) . "<br>";
                }
            }

            echo "<br>" . form_label("Preço") .
            form_input(array('name'=>'preco', 'type'=>'number', 'step'=>'any', 'value'=>$produto[0]->preco)) . "<br>" . "<br>" .
            form_label("Largura da caixa em mm") .
            form_input(array('name'=>'largura', 'type'=>'number', 'value'=>$produto[0]->largura_caixa_mm)) . "<br>" . "<br>" .
            form_label("Altura da caixa em mm") .
            form_input(array('name'=>'altura', 'type'=>'number', 'value'=>$produto[0]->altura_caixa_mm)) . "<br>" . "<br>" .
            form_label("Comprimento da caixa em mm") .
            form_input(array('name'=>'comprimento', 'type'=>'number', 'value'=>$produto[0]->comprimento_caixa_mm)) . "<br>" . "<br>" .
            form_label("Peso da caixa em gramas") .
            form_input(array('name'=>'peso', 'type'=>'number', 'value'=>$produto[0]->peso_gramas)) . "<br>" . "<br>" .
            form_label("Ativo/Inativo(1/0)") .
            form_input(array('name'=>'estado', 'type'=>'number','min'=>'0', 'max'=>'1', 'value'=>$produto[0]->ativo)) . "<br>" . "<br>" .
            form_hidden('id', $produto[0]->id) .
            form_submit("btnEdit", "Salvar Alteração") . "<br>" . "<br>" .
            form_close();
        ?>
    </div>
</div>
