<div id="homebody">
    <div class="row-fluid" >
        <?php
            echo form_open(base_url('administracao/editar_frete')) . "<br>" . "<br>" .
            form_label("Peso mínimo:") .
            form_input(array('name'=>'peso_de', 'step'=>'any', 'type'=>'number', 'value'=>$frete[0]->peso_de)) . "<br>" . "<br>" .
            form_label("Peso máximo:") .
            form_input(array('name'=>'peso_ate', 'step'=>'any', 'type'=>'number', 'value'=>$frete[0]->peso_ate)) . "<br>" . "<br>" .
            form_label("Preço:") .
            form_input(array('name'=>'preco', 'step'=>'any', 'type'=>'number', 'value'=>$frete[0]->preco)) . "<br>" . "<br>" .
            form_label("Adicional Kg:") .
            form_input(array('name'=>'kg_adicional', 'step'=>'any', 'type'=>'number', 'value'=>$frete[0]->adicional_kg)) . "<br>" . "<br>" .
            form_label("UF:") .
            form_input(array('name'=>'uf', 'value'=>$frete[0]->uf)) . "<br>" . "<br>" .
            form_hidden('id', $frete[0]->id) .
            form_submit("btnEdit", "Salvar Alteração") . "<br>" . "<br>" .
            form_close();
        ?>
    </div>
