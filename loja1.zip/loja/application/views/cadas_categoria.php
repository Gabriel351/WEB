<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3>Categorias</h3>
    </div>

    <?php
        if($excluir_fail == true) {
            echo "<script type='text/javascript'>" .
            "alert('Exclusão não pode ser feita, pois há produtos relacionados a essa categoria!'); " .
            "</script>";
        }
    ?>
    <div class="container">
        <table class="table table-brodred table-striped" id="tabela">
            <tr>
                <th id="titullo">Título</th>
                <th id="des">Descrição</th>
                <th id='oper'>Operações</th>
            </tr>
            <?php
                foreach ($categorias as $c) {
                    echo "<tr>" .
                        "<td id='titullo'>" . $c->titulo . "</td>" .
                        "<td id='des'>" . $c->descricao . "</td>" .
                        "<td>" . anchor(base_url("administracao/editar_categoria/". $c->id),
                        "Editar",array("class"=>"btn btn-warning","id"=>"botao")) .
                        anchor(base_url("administracao/excluir_categoria/" . $c->id),"Excluir",array("class"=>"btn btn-danger","id"=>"botao")); "</td>" .
                    "</tr>";
                }
            ?>
        </table>
        <?php
            echo anchor(base_url("administracao/nova_categoria"),"Novo Item",array("class"=>"btn btn-primary","id"=>"botao1"));
        ?>
    </div>

</div>
