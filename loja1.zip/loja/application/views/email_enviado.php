<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3> Seja Bem-Vindo à nossa loja . </h3>
        <p> Email enviado com sucesso. </p>
     </div>
</div>
