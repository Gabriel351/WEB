<div id="homebody">
    <div class="row-fluid" >
        <?php
            echo form_open(base_url('administracao/new_salvar')) . "<br>" . "<br>" .
            "<div class='row' id='edit'>" . "<div class='col-md-6'>" .
            form_label("Título:") . "<br>" .
            form_input(array('id'=>'titulo2', 'name'=>'titulo2', 'Placeholder'=>'Titulo')) .
            "</div>" .
            form_label("Descricao:") . "<br>" .
            form_textarea(array('id'=>'descricao2', 'name'=>'descricao2', 'Placeholder'=>'Descrição')) .
            "</div>" .
            form_submit("btnEdit", "Criar Categoria") .
            form_close()
        ?>
    </div>
</div>
