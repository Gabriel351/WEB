<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3>Produtos</h3>
    </div>

    <?php
        if($operacao == 1) {
            echo "<script type='text/javascript'>" .
            "alert('Operação realizada com sucesso!'); " .
            "</script>";
        }
        if($operacao == 2) {
            echo "<script type='text/javascript'>" .
            "alert('A operação falhou!'); " .
            "</script>";
        }
    ?>
    <div class="container">
        <table class="table table-brodred table-striped" id="tabela">
            <tr>
                <th id='codigo1'>Código</th>
                <th id="titulo1">Título</th>
                <th id="des1">Descrição</th>
                <th id='preco1'>Preço</th>
                <th id='oper1'>Operações</th>
            </tr>
            <?php
                foreach ($produtos as $p) {
                    echo "<tr>" .
                        "<td id='codigo1'>" . $p->codigo . "</td>" .
                        "<td id='titulo1'>" . $p->titulo . "</td>" .
                        "<td id='des1'>" . $p->descricao . "</td>" .
                        "<td id='preco1'>" . $p->preco . "</td>" .
                        "<td>" . anchor(base_url("administracao/editar_produto/". $p->id),
                        "Editar",array("class"=>"btn btn-warning","id"=>"botao")) .
                        anchor(base_url("administracao/excluir_produto/" . $p->id),"Excluir",array("class"=>"btn btn-danger","id"=>"botao2")); "</td>" .
                    "</tr>";
                }
            ?>
        </table>
        <?php
            echo anchor(base_url("administracao/novo_produto"),"Novo Item",array("class"=>"btn btn-primary","id"=>"botao1"));
        ?>
    </div>

</div>
