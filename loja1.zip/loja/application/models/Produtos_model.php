<?php defined('BASEPATH') OR exit('No direct script access allowed');
    class Produtos_model extends CI_Model {
        public function __construct(){
            parent::__construct();
        }

        public function detalhes_produto($id) {
            $this->db->where('id',$id);
            return $this->db->get('produtos')->result();
        }

        public function listar_produtos(){
            $this->db->order_by('titulo','ASC');
            return $this->db->get('produtos')->result();
        }

        public function destaques_home($quantos = 3){
            $this->db->limit($quantos);
            $this->db->order_by('id','random');
            return $this->db->get('produtos')->result();
        }

        public function busca($buscar){
            $this->db->like('titulo',$buscar);
            $this->db->or_like('descricao',$buscar);
            return $this->db->get('produtos')->result();
        }

        public function salvar($check, $valores) {
            $aux;
            if ($this->db->insert('produtos', $valores)) {
                $aux = 1;
            } else {
                $aux = 2;
            }
            $this->db->where('codigo', $valores['codigo']);
            $produto = $this->db->get('produtos')->result();
            $id = $produto[0]->id;
            foreach ($check as $c) {
                $dados['produto'] = $id;
                $dados['categoria'] = $c;
                if ($this->db->insert('produtos_categoria', $dados)) {
                    $aux = 1;
                } else {
                    $aux = 2;
                    break;
                }
            }

            return $aux;
        }

        public function editar($dados, $valores) {
            $this->db->where('id', $dados['id']);
            $aux;
            if ($this->db->update('produtos', $dados)) {
                $aux = 1;
            } else {
                $aux = 2;
            }

            //deletar todos produto_categoria relacionada ao produto
            $this->db->where('produto', $dados['id']);
            $this->db->delete('produtos_categoria');

            //inserir novas relações do produto_categoria
            foreach ($valores as $v) {
                $dados1['produto'] = $dados['id'];
                $dados1['categoria'] = $v;
                if ($this->db->insert('produtos_categoria', $dados1)) {
                    $aux = 1;
                } else {
                    $aux = 2;
                    break;
                }
            }

            return $aux;
        }

        public function excluir($id) {
            $this->db->where('produto', $id);
            $aux;
            //deletar produtos_categoria
            if ($this->db->delete('produtos_categoria')) {
                $aux = 1;
            } else {
                $aux = 2;
            }

            //deletar produto
            $this->db->where('id', $id);
            if ($this->db->delete('produtos')) {
                $aux = 1;
            } else {
                $aux = 2;
            }

            return $aux;
        }
    }
