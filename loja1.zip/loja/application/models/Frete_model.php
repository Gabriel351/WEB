<?php defined('BASEPATH') OR exit('No direct script access allowed');
    class Frete_model extends CI_Model {
        public function __construct(){
            parent::__construct();
        }

        public function listar_frete(){
            return $this->db->get('tb_transporte_preco')->result();
        }

        public function inserir_frete($dados) {
            if ($this->db->insert('tb_transporte_preco', $dados)) {
                return 1;
            } else {
                return 2;
            }
        }

        public function detalhes_frete($id) {
            $this->db->where('id',$id);
            return $this->db->get('tb_transporte_preco')->result();
        }

        public function update_frete($dados) {
            $this->db->where('id',$dados['id']);
            if ($this->db->update('tb_transporte_preco', $dados)) {
                return 1;
            } else {
                return 2;
            }
        }

        public function delete_frete($id) {
            $this->db->where('id', $id);
            if ($this->db->delete('tb_transporte_preco')) {
                return 1;
            } else {
                return 2;
            }
        }
    }
