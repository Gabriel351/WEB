<?php defined('BASEPATH') or exit('No direct script access allowed');
    class Administracao extends CI_Controller {
        public $categorias;

        public function __construct(){
            parent::__construct();
            $this->load->model('categorias_model','modelcategorias');
            $this->load->model('produtos_model','modelprodutos');
            $this->load->model('frete_model','modelfrete');
            $this->categorias1 = $this->modelcategorias->listar_categorias();
            $this->produtos1 = $this->modelprodutos->listar_produtos();
        }

        public function index() {
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('administracao');
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        //categoria
        public function categorias() {
            $data_header['categorias'] = $this->categorias1;
            $data_header['excluir_fail'] = false;
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('cadas_categoria',$data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }


        public function categorias_excluir_erro() {
            $data_header['categorias'] = $this->categorias1;
            $data_header['excluir_fail'] = true;
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('cadas_categoria',$data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function editar_categoria($id) {
            $dados['categoria'] = $this->modelcategorias->listar_produtos_categoria($id);
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('edit_categoria',$dados);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function edit_salvar($id) {
            $txt = $this->input->post('texto1');
            $titulo = $this->input->post('titulo1');
            $this->modelcategorias->salvar_categoria($txt, $titulo, $id);
            redirect(base_url('administracao/categorias'));
        }

        public function excluir_categoria($id) {
            $listar = $this->modelcategorias->listar_produtos_categoria($id);
            if ($listar['produtos'] == null) {
                $this->modelcategorias->deletar_categoria($id);
                redirect(base_url('administracao/categorias'));
            } else {
               redirect(base_url('administracao/categorias_excluir_erro'));
            }
        }

        public function nova_categoria(){
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('new_categoria');
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function new_salvar() {
            $txt = $this->input->post('descricao2');
            $titulo = $this->input->post('titulo2');
            $this->modelcategorias->criar_categoria($txt,$titulo);
            redirect(base_url('administracao/categorias'));
        }

        //produto
        public function produtos($valor) {
            $data_header['produtos'] = $this->produtos1;
            $data_header['operacao'] = $valor;
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('cadas_produtos',$data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

         public function novo_produto(){
            $data_header['categorias'] = $this->categorias1;
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('novo_produto', $data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function salvar_produto() {
            $dados['codigo'] = $this->input->post('codigo');
            $dados['titulo'] = $this->input->post('titulo');
            $dados['descricao'] = $this->input->post('descricao');
            $dados['preco'] = $this->input->post('preco');
            $dados['largura_caixa_mm'] = $this->input->post('largura');
            $dados['altura_caixa_mm'] = $this->input->post('altura');
            $dados['comprimento_caixa_mm'] = $this->input->post('comprimento');
            $dados['peso_gramas'] = $this->input->post('peso');
            $dados['ativo'] = 1;
            $valores = $this->input->get_post('categorias[]');
            $inserir = $this->modelprodutos->salvar($valores, $dados);
            redirect("administracao/produtos/" . $inserir);
        }

        public function editar_produto($id) {
            $data_header['categorias1'] = $this->categorias1;
            $data_header['categorias2'] = $this->modelcategorias->produto_categoria($id);
            $data_header['produto'] = $this->modelprodutos->detalhes_produto($id);
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('edit_produto', $data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function update_produto() {
            $dados['id'] = $this->input->post('id');
            $dados['codigo'] = $this->input->post('codigo');
            $dados['titulo'] = $this->input->post('titulo');
            $dados['descricao'] = $this->input->post('descricao');
            $dados['preco'] = $this->input->post('preco');
            $dados['largura_caixa_mm'] = $this->input->post('largura');
            $dados['altura_caixa_mm'] = $this->input->post('altura');
            $dados['comprimento_caixa_mm'] = $this->input->post('comprimento');
            $dados['peso_gramas'] = $this->input->post('peso');
            $dados['ativo'] = $this->input->post('estado');
            $valores = $this->input->get_post('categorias[]');
            $inserir = $this->modelprodutos->editar($dados, $valores);
            redirect("administracao/produtos/" . $inserir);
        }

        public function excluir_produto($id) {
            $deletar = $this->modelprodutos->excluir($id);
            redirect("administracao/produtos/" . $deletar);
        }

        //frete
        public function frete($valor) {
            $data_header['frete'] = $this->modelfrete->listar_frete();
            $data_header['operacao'] = $valor;
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('frete', $data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function frete_view() {
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('novo_frete');
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function incluir_frete() {
            $dados['peso_de'] = $this->input->post('peso_de');
            $dados['peso_ate'] = $this->input->post('peso_ate');
            $dados['preco'] = $this->input->post('preco');
            $dados['adicional_kg'] = $this->input->post('kg_adicional');
            $dados['uf'] = $this->input->post('uf');
            $teste = $this->modelfrete->inserir_frete($dados);
            redirect("administracao/frete/" . $teste);
        }

        public function frete_edit_view($id) {
            $f['frete'] = $this->modelfrete->detalhes_frete($id);
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('edit_frete', $f);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function editar_frete() {
            $dados['peso_de'] = $this->input->post('peso_de');
            $dados['id'] = $this->input->post('id');
            $dados['peso_ate'] = $this->input->post('peso_ate');
            $dados['preco'] = $this->input->post('preco');
            $dados['adicional_kg'] = $this->input->post('kg_adicional');
            $dados['uf'] = $this->input->post('uf');
            $teste = $this->modelfrete->update_frete($dados);
            redirect("administracao/frete/" . $teste);
        }

        public function excluir_frete($id) {
            $teste = $this->modelfrete->delete_frete($id);
            redirect("administracao/frete/" . $teste);
        }
    }
