<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banco extends CI_Controller {

    public function inserir() {
        $data = $this->input->post('data');
        $num = $this->input->post('integrantes');
        $nome = $this->input->post('banda');
        $cabum = explode("/", $data);
        if ($data != "" && $num != "" && $nome != "") { 
		    $dados['Nome'] = $nome;
		    $dados['Data_Fundacao'] = $cabum[2] . "-" . $cabum[1] . "-" . $cabum[0];
 		    $dados['Quant_Integrantes'] = $num;
            if($this->db->insert('dados', $dados)){
		    	redirect(base_url('administracao'));
		    }else{
		    	echo "Nao foi possível adicionar a banda";
		    }
        }else {
		    echo "Nao foi possível adicionar a banda pois há campos vazios";
        }
	}

    public function alterar() {
        $data = $this->input->post('data');
        $num = $this->input->post('integrantes');
        $nome = $this->input->post('banda');
        $cabum = explode("/", $data);
        if ($data != "" && $num != "" && $nome != "") { 
		    $dados['Nome'] = $nome;
		    $dados['Data_Fundacao'] = $cabum[2] . "-" . $cabum[1] . "-" . $cabum[0];
 		    $dados['Quant_Integrantes'] = $num;
            $this->db->where('ID',$this->input->post('id'));
            if($this->db->update('dados', $dados)){
		    	redirect(base_url('administracao'));
		    }else{
		    	echo "Nao foi possível alterar a banda";
		    }
        }else {
		    echo "Nao foi possível alterar a banda pois há campos vazios";
        }
	}

    public function excluir($id) {
        $this->db->where('ID', $id);
        if ($this->db->delete('dados')) {
		    redirect(base_url('administracao'));
        }else {
            echo "Não foi possível a banda do banco de dados";
        }
    }
}
?>
