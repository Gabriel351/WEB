<?php defined('BASEPATH') or exit('No direct script access allowed');
	class Pdf extends CI_Controller{
		function gerar_pdf() {
			$data['dado'] = $this->db->get('dados')->result();
			$this->load->view('ver_pdf',$data);
		}
	}	
