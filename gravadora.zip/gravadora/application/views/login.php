<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Gerenciador de Bandas</title>
		<?php
	    	echo link_tag("assets/css/bootstrap.min.css");
		    echo link_tag("assets/css/estilo.css");
        ?>
        <script type="text/javascript" src="<?php echo base_url() .'assets/js/jquery-3.2.0.min.js'?>"></script>
		<script type="text/javascript" src="<?php echo base_url() .'assets/js/bootstrap.min.js'?>"></script>
	</head>
	<body>
    <br><br><br><br><br><br>
    <div class="row">
	<div id="cadas_alter" class="col-md-6 col-md-offset-3">
        <div id="corpo1">
		<?php
			$atributos = array('name' => 'efetuar_login', 'id' => 'efetuar_login');
			echo form_open(base_url('efetuar_login/login'), $atributos) .
			form_label("Usuário: ","txt_usuario") . br() . 
			form_input('txt_usuario') . br() . 
			form_label("Senha: ","txt_senha") . br() . 
			form_password('txt_senha') . br() .br() .
			form_submit("btn_enviar", "Logar") . br() .br() .
			form_close();
		?>
        </div>
    </div>
    </div>
	</body>
</html>
