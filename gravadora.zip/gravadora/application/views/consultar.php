<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Gerenciador de Bandas</title>
        <?php
	    	echo link_tag("assets/css/bootstrap.min.css");
		    echo link_tag("assets/css/estilo.css");
        ?>
        <script type="text/javascript" src="<?php echo base_url() .'assets/js/jquery-3.2.0.min.js'?>"></script>
		<script type="text/javascript" src="<?php echo base_url() .'assets/js/bootstrap.min.js'?>"></script>
	</head>
	 <body>
    <br><br><br>
    <div class="row">
	    <div id="cadas_alter" class="col-md-10 col-md-offset-1">
            <div id="corpo1">
                <?php
                      echo anchor(base_url("administracao"),"Home") . anchor(base_url("administracao/cadastrar"),"Cadastrar").
                      anchor(base_url('administracao/consultar'),"Consultar") . anchor(base_url('administracao/gerenciar'),"Gerenciar").
                      anchor(base_url("pdf/gerar_pdf"),"Gerar PDF") . anchor(base_url("efetuar_login/logout"),"Logout").br();
                 ?>
            <h2>Consultar</h2>
            </div>
            <?php
                  foreach($dado as $post){
	                echo  "Banda: ". $post->Nome . " - " . " Data de fundação: " . date("d/m/Y", strtotime($post->Data_Fundacao)). 
                    " - " . " Número de integrantes: ".$post->Quant_Integrantes.br();
                  }
            ?>
        </div>
    </div>
    </body>
</html>
