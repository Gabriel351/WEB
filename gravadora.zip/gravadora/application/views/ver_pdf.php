<?php
	require_once('assets/fpdf/fpdf.php');
	$pdf = new FPDF();
	$pdf->AddPage();
    /*$num = 0;
    foreach ($dado as $post) {
	    $pdf->SetFont('Arial','B',18);
	    $nome = utf8_decode($post->Nome);
	    $pdf->Write(30, "Banda: " . $nome);
	    $pdf->Ln(15);
        $pdf->SetFont('Arial','',13);
	    $data =  date("d/m/Y", strtotime($post->Data_Fundacao));
	    $pdf->Write(30, "Fundada em: " . $data);
	    $pdf->Ln(10);
	    $integrantes = utf8_decode($post->Quant_Integrantes);
	    $pdf->Write(30, "Quantidade de Integrantes: " . $integrantes);
	    $pdf->Ln(35);
        $num++;
        if ($num % 4 == 0) {
            $pdf->AddPage();
        }
    }
	$pdf->Output();*/
	$pdf->SetFillColor(139,87,36);
    $pdf->SetTextColor(255);
    $pdf->SetDrawColor(128,0,0);
    $pdf->SetLineWidth(.3);
    $pdf->SetFont('arial','B',15);
    $w = 60;
    $header = array('banda',utf8_decode('data de fundação'), utf8_decode('número de integrantes'));
    for($i=0;$i<count($header);$i++)
        $pdf->Cell($w,7,$header[$i],1,0,'C',true);
    $pdf->Ln();
    $pdf->SetFillColor(224,235,255);
    $pdf->SetTextColor(0);
    $pdf->SetFont('arial','',11);
    $cor = false;
    foreach($dado as $post)
    {
        $pdf->Cell($w,6,utf8_decode($post->Nome),'LR',0,'L',$cor);
        $pdf->Cell($w,6,date("d/m/Y", strtotime($post->Data_Fundacao)),'LR',0,'C',$cor);
        $pdf->Cell($w,6,number_format($post->Quant_Integrantes),'LR',0,'R',$cor);
        $pdf->Ln();
        $cor = !$cor;
    }
    $pdf->Cell(($w*3),0,'','T');
    $pdf->Output();
?>

