<div id="homebody">
    <div class="row-fluid" >
        <?php
            echo form_open(base_url('administracao/edit_salvar/' . $categoria['detalhes'][0]->id)) . "<br>" . "<br>" .
            "<div class='row' id='edit'>" . "<div class='col-md-6'>" .
            form_label("Título:") . "<br>" .
            form_input(array('id'=>'titulo1','name'=>'titulo1', 'value'=>$categoria['detalhes'][0]->titulo)) .
            "</div>" .
            form_label("Mensagem:",'texto1') . "<br>" .
            form_textarea(array('id'=>'texto1','name'=>'texto1', 'value'=>$categoria['detalhes'][0]->descricao)) . "<br>" .
            "</div>" .
            form_submit("btnEdit","Salvar Alteração") .
            form_close()
        ?>
    </div>
</div>
