<?php defined('BASEPATH') or exit('No direct script access allowed');
    class Administracao extends CI_Controller {
        public $categorias;

        public function __construct(){
            parent::__construct();
            $this->load->model('categorias_model','modelcategorias');
            $this->load->model('produtos_model','modelprodutos');
            $this->categorias1 = $this->modelcategorias->listar_categorias();
        }

        public function index() {
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('administracao');
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function categorias() {
            $data_header['categorias'] = $this->categorias1;
            $data_header['excluir_fail'] = false;
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('cadas_categoria',$data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function categorias_excluir_erro() {
            $data_header['categorias'] = $this->categorias1;
            $data_header['excluir_fail'] = true;
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('cadas_categoria',$data_header);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function editar_categoria($id) {
            $dados['categoria'] = $this->modelcategorias->listar_produtos_categoria($id);
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('edit_categoria',$dados);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function edit_salvar($id) {
            $txt = $this->input->post('texto1');
            $titulo = $this->input->post('titulo1');
            $this->modelcategorias->salvar_categoria($txt, $titulo, $id);
            redirect(base_url('administracao/categorias'));
        }

        public function excluir_categoria($id) {
            $listar = $this->modelcategorias->listar_produtos_categoria($id);
            if ($listar['produtos'] == null) {
                $this->modelcategorias->deletar_categoria($id);
                redirect(base_url('administracao/categorias'));
            } else {
               redirect(base_url('administracao/categorias_excluir_erro'));
            }
        }

        public function nova_categoria(){
            $this->load->view('html-header');
            $this->load->view('header_adm');
            $this->load->view('new_categoria');
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

        public function new_salvar() {
            $txt = $this->input->post('descricao2');
            $titulo = $this->input->post('titulo2');
            $this->modelcategorias->criar_categoria($txt,$titulo);
            redirect(base_url('administracao/categorias'));
        }
    }
